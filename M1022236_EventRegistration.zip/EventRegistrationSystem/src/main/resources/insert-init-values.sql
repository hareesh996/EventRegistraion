insert into employees values('M100100','Karthik Kumar',to_date('2013-02-05','YYYY-MM-DD'),'karthik_kumar');
insert into employees values('M100108','Ramesh Kulkarni',to_date('2013-02-05','YYYY-MM-DD'),'ramesh_kulkarni');
insert into employees values('M100189','Rohith Agrawal M',to_date('2013-03-22','YYYY-MM-DD'),'rohith_agrawal_m');
insert into employees values('M100190','Magesh Narayanan',to_date('2013-03-22','YYYY-MM-DD'),'magesh_narayanan');

insert into events values(1,'Trekking','Held Every Month.');
insert into events values(2,'Guitar Classes','Weekly 3 sessions.');
insert into events values(3,'Yoga Classes','Saturdat and sunday classes.');
insert into events values(4,'Health & Diet tips','Every Friday 5PM to PM.');