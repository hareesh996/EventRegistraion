package com.mindtree.evtmanagement.dao.vo;

public class EvtRegResponse {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
