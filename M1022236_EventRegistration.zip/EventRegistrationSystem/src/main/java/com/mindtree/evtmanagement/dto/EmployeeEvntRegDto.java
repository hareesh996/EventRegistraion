package com.mindtree.evtmanagement.dto;

public class EmployeeEvntRegDto {

	private String mid;
	private long eventId;
	
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public long getEventId() {
		return eventId;
	}
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}
	
}
